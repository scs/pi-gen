from smartmeter_datacollector_configurator.app import main

if __name__ == '__main__':
    main()
